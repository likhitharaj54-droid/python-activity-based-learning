# Test Cases

| Test | Input / Scenario | Expected Result |
|---|---|---|
| Anu meets all criteria | 88 marks, income 180000, attendance 92 | Anu is eligible |
| Bala misses marks rule | 76 marks | Bala is not eligible |
