applicants = [
    {"name": "Anu", "marks": 88, "income": 180000, "attendance": 92},
    {"name": "Bala", "marks": 76, "income": 150000, "attendance": 90},
    {"name": "Charan", "marks": 84, "income": 300000, "attendance": 89},
    {"name": "Divya", "marks": 91, "income": 200000, "attendance": 86},
]
shortlisted = []

print("Scholarship Shortlisting")
for person in applicants:
    eligible = (person["marks"] >= 80 and
                person["income"] <= 250000 and
                person["attendance"] >= 85)
    status = "Eligible" if eligible else "Not eligible"
    print(f'{person["name"]}: {status}')
    if eligible:
        shortlisted.append(person["name"])

print(f"Shortlisted applicants: {len(shortlisted)}")
print(", ".join(shortlisted) if shortlisted else "None")
