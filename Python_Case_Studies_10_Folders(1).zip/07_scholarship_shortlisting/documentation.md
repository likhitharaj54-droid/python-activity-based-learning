# Case Study 7: Multi-Stage Scholarship Shortlisting

## 1. Problem Statement
Shortlist scholarship applicants using eligibility rules for marks, family income, and attendance.

## 2. Objectives
- Evaluate applicants against multiple conditions.
- Explain why applicants are eligible or not eligible.
- Count shortlisted applicants.

## 3. Assumptions
- Minimum marks are 80%.
- Annual family income must be at most ₹250,000.
- Attendance must be at least 85%.
- These sample thresholds are illustrative, not official rules.

## 4. Algorithm
1. Store applicant records.
2. Check marks, income, and attendance for each applicant.
3. Shortlist applicants who meet all conditions.
4. Print decisions and the shortlist count.

## 5. Flowchart
```text
[Start]
   |
   v
[Initialise input data]
   |
   v
[Process records / calculate values]
   |
   v
[Apply decision conditions]
   |
   v
[Display summary and results]
   |
   v
[End]
```

## 6. Pseudocode
```text
shortlisted ← empty list
FOR each applicant:
    IF marks >= 80 AND income <= 250000 AND attendance >= 85:
        add applicant to shortlisted
        PRINT eligible
    ELSE PRINT not eligible
PRINT shortlisted count

```

## 7. Python Source Code
See [`main.py`](main.py).

## 8. Test Cases
See [`test_cases.md`](test_cases.md).

## 9. Output
- `output.txt` contains the captured output from running `main.py`.
- `output.png` is a rendered image of that console output.

## 10. Conclusion
The program uses compound Boolean conditions to apply a multi-stage eligibility check.
