rooms = {"Room A": {"capacity": 2, "students": []},
         "Room B": {"capacity": 1, "students": []}}
students = ["Akhil", "Bhavana", "Chandu", "Deepa"]

unallocated = []
for student in students:
    assigned = False
    for room_name, room in rooms.items():
        if len(room["students"]) < room["capacity"]:
            room["students"].append(student)
            assigned = True
            break
    if not assigned:
        unallocated.append(student)

print("Hostel Room Allocation")
for room_name, room in rooms.items():
    print(f'{room_name}: {", ".join(room["students"]) or "Empty"} '
          f'({len(room["students"])}/{room["capacity"]})')
print("Unallocated students:", ", ".join(unallocated) if unallocated else "None")
