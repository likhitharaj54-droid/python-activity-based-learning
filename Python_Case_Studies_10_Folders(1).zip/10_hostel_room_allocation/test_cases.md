# Test Cases

| Test | Input / Scenario | Expected Result |
|---|---|---|
| Four students, capacity three | Two rooms with capacities 2 and 1 | Three students allocated; one remains unallocated |
| One student | One student and empty rooms | Student is assigned to Room A |
