# Case Study 10: University Hostel Room Allocation

## 1. Problem Statement
Allocate students to hostel rooms based on room capacity and student preferences, then list students who remain unallocated.

## 2. Objectives
- Track room capacities and occupants.
- Assign students to rooms with available capacity.
- Report allocations and students still waiting.

## 3. Assumptions
- Each student is allocated at most once.
- Room capacities are positive integers.
- The example assigns students in order to the first room with capacity.

## 4. Algorithm
1. Create rooms with capacities and an empty occupant list.
2. Loop through students in order.
3. Assign each student to the first room with space.
4. Report room occupants and any unallocated students.

## 5. Flowchart
```text
[Start]
   |
   v
[Initialise input data]
   |
   v
[Process records / calculate values]
   |
   v
[Apply decision conditions]
   |
   v
[Display summary and results]
   |
   v
[End]
```

## 6. Pseudocode
```text
rooms ← {A: capacity 2, B: capacity 1}
unallocated ← empty list
FOR each student:
    find first room with free capacity
    IF found: assign student ELSE add to unallocated
PRINT room assignments and unallocated list

```

## 7. Python Source Code
See [`main.py`](main.py).

## 8. Test Cases
See [`test_cases.md`](test_cases.md).

## 9. Output
- `output.txt` contains the captured output from running `main.py`.
- `output.png` is a rendered image of that console output.

## 10. Conclusion
The program models a simple allocation workflow using nested dictionaries, loops, and capacity checks.
