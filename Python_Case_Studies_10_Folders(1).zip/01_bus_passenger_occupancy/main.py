CAPACITY = 40
stops = [(0, 18), (4, 10), (7, 12), (5, 3)]  # (leaving, boarding)
passengers = 0
max_occupancy = 0

print("Bus Passenger Occupancy Simulation")
for stop, (leaving, boarding) in enumerate(stops, start=1):
    passengers = max(0, passengers - leaving)
    passengers = min(CAPACITY, passengers + boarding)
    max_occupancy = max(max_occupancy, passengers)
    print(f"Stop {stop}: passengers = {passengers}")

print(f"Final passengers: {passengers}")
print(f"Maximum occupancy: {max_occupancy}/{CAPACITY}")
