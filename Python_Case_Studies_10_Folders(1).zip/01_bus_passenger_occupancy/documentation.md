# Case Study 1: Bus Passenger Occupancy Simulation

## 1. Problem Statement
Simulate passengers boarding and leaving a bus at several stops and report the final passenger count and maximum occupancy.

## 2. Objectives
- Track passenger count across multiple stops.
- Prevent passenger count from becoming negative or exceeding bus capacity.
- Report the maximum occupancy observed.

## 3. Assumptions
- Bus capacity is 40 passengers.
- At each stop, passengers leave before new passengers board.
- Input values are non-negative integers.
- Invalid stop data is skipped after validation.

## 4. Algorithm
1. Start with zero passengers and maximum occupancy.
2. For each stop, read leaving and boarding counts.
3. Subtract leaving passengers, but do not allow a negative count.
4. Add boarding passengers up to available capacity.
5. Update and display occupancy.

## 5. Flowchart
```text
[Start]
   |
   v
[Initialise input data]
   |
   v
[Process records / calculate values]
   |
   v
[Apply decision conditions]
   |
   v
[Display summary and results]
   |
   v
[End]
```

## 6. Pseudocode
```text
capacity ← 40; passengers ← 0; max_occupancy ← 0
FOR each stop (leaving, boarding):
    passengers ← max(0, passengers - leaving)
    passengers ← min(capacity, passengers + boarding)
    max_occupancy ← max(max_occupancy, passengers)
PRINT passengers and max_occupancy

```

## 7. Python Source Code
See [`main.py`](main.py).

## 8. Test Cases
See [`test_cases.md`](test_cases.md).

## 9. Output
- `output.txt` contains the captured output from running `main.py`.
- `output.png` is a rendered image of that console output.

## 10. Conclusion
The simulation tracks passenger occupancy stop by stop and respects the bus capacity.
