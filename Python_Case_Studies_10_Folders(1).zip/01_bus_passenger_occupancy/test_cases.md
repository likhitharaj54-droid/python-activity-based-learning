# Test Cases

| Test | Input / Scenario | Expected Result |
|---|---|---|
| Four stops | [(0,18),(4,10),(7,12),(5,3)] | Final passengers: 27; Maximum occupancy: 30/40 |
| No boarding | [] | Final passengers: 0; Maximum occupancy: 0/40 |
