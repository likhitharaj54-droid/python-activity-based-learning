# Python-Activity-Based-Learning

## Student Details
- **Name:** N. Likhitha
- **Roll Number:** 26000968
- **Branch:** CSM AIML
- **Section:** 2

## Selected Case Studies
1. Bus Passenger Occupancy Simulation
2. Hackathon Team Formation and Ranking
3. Food Waste Monitoring System
4. Retail Order Dispatch and Return Analysis
5. Energy Conservation Before-and-After Analysis
6. Nested List Sports Performance Analysis
7. Multi-Stage Scholarship Shortlisting
8. Integrated University Fee and Eligibility Audit
9. Multi-Branch Retail Inventory Transfer
10. University Hostel Room Allocation

## Repository Contents
Each case-study folder contains:
- `documentation.md` — problem statement, objectives, assumptions, algorithm, flowchart, pseudocode, and conclusion
- `main.py` — Python source code
- `test_cases.md` — test cases
- `output.txt` — captured program output
- `output.png` — output image

## How to Run the Programs
1. Install Python 3.
2. Open a terminal in any case-study folder.
3. Run:
   ```bash
   python main.py
   ```
   On some systems, use `python3 main.py`.

## Uploading to GitHub
1. Create a GitHub repository named **Python-Activity-Based-Learning**.
2. Upload the contents of this folder to the repository.
3. Check that each program runs correctly.
4. Copy your repository URL and submit it to your Python Programming faculty.

## Note
The flowcharts are text-based sequences in the documentation. Output images show captured console output from the included programs, not screenshots from a specific IDE. Replace or supplement them with your own IDE screenshots if required by your faculty. Scholarship thresholds and sample data are illustrative; use official rules where applicable.
