minimum_stock = 20
stock = {"Central": 35, "North": 12, "South": 18, "East": 27}
surplus = {name: qty - minimum_stock for name, qty in stock.items()
           if qty > minimum_stock}
shortages = {name: minimum_stock - qty for name, qty in stock.items()
             if qty < minimum_stock}

print("Retail Inventory Transfer Recommendations")
for needy_branch in list(shortages):
    need = shortages[needy_branch]
    for donor_branch in list(surplus):
        if need == 0:
            break
        transfer = min(need, surplus[donor_branch])
        if transfer > 0:
            print(f"Transfer {transfer} units: {donor_branch} -> {needy_branch}")
            need -= transfer
            surplus[donor_branch] -= transfer
    shortages[needy_branch] = need

for branch, remaining in shortages.items():
    if remaining:
        print(f"Unfilled shortage at {branch}: {remaining} units")
