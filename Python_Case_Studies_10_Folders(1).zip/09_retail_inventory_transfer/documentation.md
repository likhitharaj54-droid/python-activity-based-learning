# Case Study 9: Multi-Branch Retail Inventory Transfer

## 1. Problem Statement
Check stock at retail branches and recommend transfers from branches with surplus to branches below minimum stock.

## 2. Objectives
- Compare stock with a minimum threshold.
- Identify surplus and shortage branches.
- Calculate a simple transfer recommendation.

## 3. Assumptions
- All branches track the same product.
- Minimum stock is 20 units per branch.
- Transfer recommendations do not exceed available surplus or shortage.

## 4. Algorithm
1. Store branch stock levels.
2. Calculate surplus above minimum and shortage below minimum.
3. Match available surplus to shortages.
4. Print recommended transfers and remaining shortages.

## 5. Flowchart
```text
[Start]
   |
   v
[Initialise input data]
   |
   v
[Process records / calculate values]
   |
   v
[Apply decision conditions]
   |
   v
[Display summary and results]
   |
   v
[End]
```

## 6. Pseudocode
```text
minimum ← 20
surplus ← branches with stock > minimum
shortage ← branches with stock < minimum
FOR each shortage branch:
    transfer from surplus branches until shortage met or surplus exhausted
PRINT transfers and remaining stock status

```

## 7. Python Source Code
See [`main.py`](main.py).

## 8. Test Cases
See [`test_cases.md`](test_cases.md).

## 9. Output
- `output.txt` contains the captured output from running `main.py`.
- `output.png` is a rendered image of that console output.

## 10. Conclusion
The program demonstrates dictionaries and greedy matching to produce practical inventory transfer recommendations.
