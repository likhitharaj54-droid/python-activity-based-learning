# Test Cases

| Test | Input / Scenario | Expected Result |
|---|---|---|
| Two shortage branches | Central 35, North 12, South 18, East 27 | Transfers reduce shortages using available surplus |
| No surplus | All branches stock below 20 | Unfilled shortages are reported |
