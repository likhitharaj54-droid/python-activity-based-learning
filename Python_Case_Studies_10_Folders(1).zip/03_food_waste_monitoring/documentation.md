# Case Study 3: Food Waste Monitoring System

## 1. Problem Statement
Record food prepared and wasted over several days and calculate the total and waste percentage.

## 2. Objectives
- Store daily food quantities.
- Calculate total prepared and wasted food.
- Find the overall waste percentage and flag high-waste days.

## 3. Assumptions
- Quantities are measured in kilograms.
- Prepared quantities are greater than zero.
- A day is flagged when waste exceeds 20% of food prepared.

## 4. Algorithm
1. Create daily records of prepared and wasted food.
2. Calculate totals for prepared and wasted quantities.
3. Calculate waste percentage.
4. List days with waste percentage above 20%.

## 5. Flowchart
```text
[Start]
   |
   v
[Initialise input data]
   |
   v
[Process records / calculate values]
   |
   v
[Apply decision conditions]
   |
   v
[Display summary and results]
   |
   v
[End]
```

## 6. Pseudocode
```text
prepared_total ← 0; waste_total ← 0
FOR each day:
    prepared_total += prepared
    waste_total += wasted
    percent ← wasted / prepared × 100
    IF percent > 20: flag day
PRINT totals and overall percentage

```

## 7. Python Source Code
See [`main.py`](main.py).

## 8. Test Cases
See [`test_cases.md`](test_cases.md).

## 9. Output
- `output.txt` contains the captured output from running `main.py`.
- `output.png` is a rendered image of that console output.

## 10. Conclusion
The program uses arithmetic and conditional statements to identify days with unusually high food waste.
