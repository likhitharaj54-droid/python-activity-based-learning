daily_data = [
    ("Monday", 50, 6),
    ("Tuesday", 45, 12),
    ("Wednesday", 55, 8),
    ("Thursday", 40, 11),
]
prepared_total = sum(row[1] for row in daily_data)
waste_total = sum(row[2] for row in daily_data)

print("Food Waste Monitoring")
for day, prepared, wasted in daily_data:
    percent = wasted / prepared * 100 if prepared else 0
    status = "HIGH WASTE" if percent > 20 else "OK"
    print(f"{day}: {wasted} kg wasted ({percent:.1f}%) - {status}")

overall = waste_total / prepared_total * 100 if prepared_total else 0
print(f"Total prepared: {prepared_total} kg")
print(f"Total wasted: {waste_total} kg")
print(f"Overall waste: {overall:.1f}%")
