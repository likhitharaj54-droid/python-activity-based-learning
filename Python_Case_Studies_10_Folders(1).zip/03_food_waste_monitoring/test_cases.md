# Test Cases

| Test | Input / Scenario | Expected Result |
|---|---|---|
| Weekly data | Prepared 190 kg; wasted 37 kg | Overall waste is about 19.5% |
| Zero prepared | Prepared quantity is 0 | Code uses 0% for that record to avoid division by zero |
