# Case Study 8: Integrated University Fee and Eligibility Audit

## 1. Problem Statement
Calculate the amount due for students, account for scholarships, and flag unpaid balances.

## 2. Objectives
- Calculate net fees after scholarship discounts.
- Compare paid amounts with net fees.
- Summarise balances and payment status.

## 3. Assumptions
- Fees and payments are non-negative.
- Scholarship percentage is between 0 and 100.
- Any positive balance is marked as due.

## 4. Algorithm
1. Store each student's fee, scholarship percentage, and amount paid.
2. Calculate discount and net fee.
3. Calculate balance due without allowing negative balances.
4. Print each status and total balance.

## 5. Flowchart
```text
[Start]
   |
   v
[Initialise input data]
   |
   v
[Process records / calculate values]
   |
   v
[Apply decision conditions]
   |
   v
[Display summary and results]
   |
   v
[End]
```

## 6. Pseudocode
```text
total_due ← 0
FOR each student:
    net_fee ← fee × (1 - scholarship_percent / 100)
    balance ← max(0, net_fee - paid)
    IF balance > 0: status ← DUE ELSE status ← PAID
    total_due += balance
PRINT each student and total_due

```

## 7. Python Source Code
See [`main.py`](main.py).

## 8. Test Cases
See [`test_cases.md`](test_cases.md).

## 9. Output
- `output.txt` contains the captured output from running `main.py`.
- `output.png` is a rendered image of that console output.

## 10. Conclusion
The audit combines percentage calculations and conditional status reporting to identify outstanding student balances.
