students = [
    {"name": "Asha", "fee": 60000, "scholarship": 25, "paid": 45000},
    {"name": "Bharat", "fee": 60000, "scholarship": 10, "paid": 30000},
    {"name": "Chitra", "fee": 55000, "scholarship": 0, "paid": 55000},
]
total_balance = 0

print("University Fee Audit")
for student in students:
    net_fee = student["fee"] * (1 - student["scholarship"] / 100)
    balance = max(0, net_fee - student["paid"])
    total_balance += balance
    status = "DUE" if balance > 0 else "PAID"
    print(f'{student["name"]}: net fee ₹{net_fee:.0f}, '
          f'paid ₹{student["paid"]}, balance ₹{balance:.0f} - {status}')

print(f"Total outstanding balance: ₹{total_balance:.0f}")
