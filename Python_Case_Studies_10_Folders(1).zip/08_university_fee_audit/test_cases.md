# Test Cases

| Test | Input / Scenario | Expected Result |
|---|---|---|
| Scholarship and payment | Asha net fee 45000 and paid 45000 | Asha balance is ₹0 and status PAID |
| Partial payment | Bharat net fee 54000 and paid 30000 | Bharat balance is ₹24000 |
