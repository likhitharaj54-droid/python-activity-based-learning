# Test Cases

| Test | Input / Scenario | Expected Result |
|---|---|---|
| Three players | Totals are 27, 25, and 28 | Meena is top performer with 28 points |
| Equal totals | Two players tie | The first maximum in the list is reported |
