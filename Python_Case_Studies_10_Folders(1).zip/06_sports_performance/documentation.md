# Case Study 6: Nested List Sports Performance Analysis

## 1. Problem Statement
Analyse players' scores stored in nested lists and find each player's total and the highest-performing player.

## 2. Objectives
- Use nested lists to store player scores.
- Calculate totals for each player.
- Identify the player with the highest total.

## 3. Assumptions
- Each player has the same number of recorded scores.
- Scores are numeric and non-negative.
- Player names correspond to the score lists by index.

## 4. Algorithm
1. Store player names and nested score lists.
2. Loop through each player's scores and calculate the total.
3. Track the highest total and player.
4. Print all totals and the best performer.

## 5. Flowchart
```text
[Start]
   |
   v
[Initialise input data]
   |
   v
[Process records / calculate values]
   |
   v
[Apply decision conditions]
   |
   v
[Display summary and results]
   |
   v
[End]
```

## 6. Pseudocode
```text
names ← [Asha, Ravi, Meena]
scores ← [[10,8,9], [7,10,8], [9,9,10]]
FOR i from 0 to length(names)-1:
    total[i] ← sum(scores[i])
best ← index of maximum total
PRINT totals and best player

```

## 7. Python Source Code
See [`main.py`](main.py).

## 8. Test Cases
See [`test_cases.md`](test_cases.md).

## 9. Output
- `output.txt` contains the captured output from running `main.py`.
- `output.png` is a rendered image of that console output.

## 10. Conclusion
Nested lists and iteration make it easy to organise and analyse multiple rounds of sports scores.
