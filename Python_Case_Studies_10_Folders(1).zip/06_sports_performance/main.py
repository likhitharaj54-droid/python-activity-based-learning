players = ["Asha", "Ravi", "Meena"]
scores = [
    [10, 8, 9],
    [7, 10, 8],
    [9, 9, 10],
]
totals = []

print("Sports Performance")
for name, player_scores in zip(players, scores):
    total = sum(player_scores)
    totals.append(total)
    print(f"{name}: {player_scores} -> total {total}")

best_index = totals.index(max(totals))
print(f"Top performer: {players[best_index]} ({totals[best_index]} points)")
