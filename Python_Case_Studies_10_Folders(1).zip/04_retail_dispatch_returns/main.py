orders = [
    ("R101", "dispatched"),
    ("R102", "returned"),
    ("R103", "pending"),
    ("R104", "dispatched"),
    ("R105", "returned"),
    ("R106", "dispatched"),
]
counts = {"dispatched": 0, "pending": 0, "returned": 0}
for order_id, status in orders:
    if status in counts:
        counts[status] += 1

total = len(orders)
return_percent = counts["returned"] / total * 100 if total else 0

print("Retail Order Summary")
print(f"Total orders: {total}")
print(f"Dispatched: {counts['dispatched']}")
print(f"Pending: {counts['pending']}")
print(f"Returned: {counts['returned']}")
print(f"Return rate: {return_percent:.1f}%")
