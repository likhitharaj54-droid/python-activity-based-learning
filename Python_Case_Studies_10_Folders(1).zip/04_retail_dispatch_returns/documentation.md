# Case Study 4: Retail Order Dispatch and Return Analysis

## 1. Problem Statement
Analyse retail orders to determine dispatch status and summarize returned orders.

## 2. Objectives
- Track order IDs and dispatch/return states.
- Count dispatched, pending, and returned orders.
- Calculate the percentage of orders returned.

## 3. Assumptions
- Each order has a unique ID.
- Status is one of dispatched, pending, or returned.
- Returned orders are counted separately from pending orders.

## 4. Algorithm
1. Create a list of order records.
2. Count each status using a loop.
3. Calculate return percentage.
4. Display the summary.

## 5. Flowchart
```text
[Start]
   |
   v
[Initialise input data]
   |
   v
[Process records / calculate values]
   |
   v
[Apply decision conditions]
   |
   v
[Display summary and results]
   |
   v
[End]
```

## 6. Pseudocode
```text
orders ← list of (id, status)
initialise dispatched, pending, returned to 0
FOR each order: increment matching status count
return_percent ← returned / total × 100
PRINT counts and percentage

```

## 7. Python Source Code
See [`main.py`](main.py).

## 8. Test Cases
See [`test_cases.md`](test_cases.md).

## 9. Output
- `output.txt` contains the captured output from running `main.py`.
- `output.png` is a rendered image of that console output.

## 10. Conclusion
The program demonstrates lists, dictionaries, and status counting for basic retail operations.
