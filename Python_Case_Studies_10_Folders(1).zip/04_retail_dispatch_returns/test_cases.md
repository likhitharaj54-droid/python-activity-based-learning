# Test Cases

| Test | Input / Scenario | Expected Result |
|---|---|---|
| Six orders | 3 dispatched, 1 pending, 2 returned | Return rate: 33.3% |
| Empty order list | No orders | Return rate is 0% |
