# Test Cases

| Test | Input / Scenario | Expected Result |
|---|---|---|
| Consumption decreases | 1200 to 930 kWh | Saved 270 kWh; reduction 22.5% |
| Consumption increases | 900 to 1000 kWh | Reports increased energy use |
