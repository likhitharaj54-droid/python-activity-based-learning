# Case Study 5: Energy Conservation Before-and-After Analysis

## 1. Problem Statement
Compare electricity consumption before and after an energy-saving activity and calculate the reduction.

## 2. Objectives
- Store before-and-after energy readings.
- Calculate the difference and percentage reduction.
- Classify whether energy use improved.

## 3. Assumptions
- Readings are in kWh and are non-negative.
- Before consumption is greater than zero.
- A positive reduction indicates energy saved.

## 4. Algorithm
1. Set before and after consumption values.
2. Calculate saved energy as before minus after.
3. Calculate percentage reduction.
4. Print whether consumption decreased, increased, or stayed the same.

## 5. Flowchart
```text
[Start]
   |
   v
[Initialise input data]
   |
   v
[Process records / calculate values]
   |
   v
[Apply decision conditions]
   |
   v
[Display summary and results]
   |
   v
[End]
```

## 6. Pseudocode
```text
before ← 1200; after ← 930
saved ← before - after
percent ← saved / before × 100 if before > 0 else 0
IF saved > 0: report reduction
ELSE IF saved < 0: report increase
ELSE: report no change

```

## 7. Python Source Code
See [`main.py`](main.py).

## 8. Test Cases
See [`test_cases.md`](test_cases.md).

## 9. Output
- `output.txt` contains the captured output from running `main.py`.
- `output.png` is a rendered image of that console output.

## 10. Conclusion
The comparison quantifies the effect of an energy-saving measure using arithmetic and conditional logic.
