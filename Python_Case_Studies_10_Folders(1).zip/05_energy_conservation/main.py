before_kwh = 1200
after_kwh = 930
saved_kwh = before_kwh - after_kwh
reduction_percent = saved_kwh / before_kwh * 100 if before_kwh > 0 else 0

print("Energy Conservation Analysis")
print(f"Before: {before_kwh} kWh")
print(f"After: {after_kwh} kWh")
if saved_kwh > 0:
    print(f"Energy saved: {saved_kwh} kWh")
elif saved_kwh < 0:
    print(f"Energy use increased by: {-saved_kwh} kWh")
else:
    print("Energy use did not change")
print(f"Percentage reduction: {reduction_percent:.1f}%")
