teams = {
    "Code Crafters": [85, 90, 88],
    "Byte Builders": [92, 87, 91],
    "Logic Legends": [80, 95, 86],
}

results = []
for name, scores in teams.items():
    results.append((name, sum(scores)))

results.sort(key=lambda item: (-item[1], item[0]))

print("Hackathon Team Ranking")
for rank, (name, total) in enumerate(results, start=1):
    print(f"{rank}. {name}: {total}/300")
