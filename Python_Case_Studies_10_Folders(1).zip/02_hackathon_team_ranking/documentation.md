# Case Study 2: Hackathon Team Formation and Ranking

## 1. Problem Statement
Store hackathon team scores, calculate totals, and rank teams from highest to lowest score.

## 2. Objectives
- Represent teams and their scores using a dictionary.
- Calculate total scores for each team.
- Sort teams to produce a clear ranking.

## 3. Assumptions
- Each team has three judging scores.
- Scores are non-negative numbers.
- Ties are resolved alphabetically by team name.

## 4. Algorithm
1. Create a dictionary of team names and judging scores.
2. Calculate each team's total score.
3. Sort teams by descending total and ascending name.
4. Print the ranking.

## 5. Flowchart
```text
[Start]
   |
   v
[Initialise input data]
   |
   v
[Process records / calculate values]
   |
   v
[Apply decision conditions]
   |
   v
[Display summary and results]
   |
   v
[End]
```

## 6. Pseudocode
```text
teams ← dictionary of team scores
FOR each team: total ← sum(scores)
ranking ← teams sorted by (-total, team_name)
PRINT rank, team name, total

```

## 7. Python Source Code
See [`main.py`](main.py).

## 8. Test Cases
See [`test_cases.md`](test_cases.md).

## 9. Output
- `output.txt` contains the captured output from running `main.py`.
- `output.png` is a rendered image of that console output.

## 10. Conclusion
Dictionaries, loops, sum(), and sorting can be combined to create a simple team-ranking system.
