# Test Cases

| Test | Input / Scenario | Expected Result |
|---|---|---|
| Three teams | Three teams with three scores each | Byte Builders ranks first with 270/300 |
| Tie | Two teams have equal totals | Alphabetical team name breaks the tie |
